#include<stdio.h>
void main(){
	int integer;
	char character;
	float floatf;


		printf("Enter char value : ");
		scanf("%c",&character);
		printf("Entered character : %c\n",character);

		printf("Enter int value : ");
		scanf("%d",&integer);
		printf("Entered integer : %d\n",integer);
	
	        printf("Enter float value : ");
		scanf("%f",&floatf);
		printf("Entered float value : %f\n",floatf);
}
