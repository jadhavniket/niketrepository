#include<stdio.h>
void main(){
	int num1,num2,avg;
	printf("Enter two number : ");
	scanf("%d%d",&num1,&num2);

	avg = (num1+num2)/2;
	printf("Average : %d\n",avg);
}
